#include "RenderManager.h"

void RenderManager::Start() {
	cout << "Render Manager Start" << endl;
}

void RenderManager::Update() {
	cout << "Render Manager Update" << endl;
}

void RenderManager::Shutdown() {
	cout << "Render Manager Shutdown" << endl;
}