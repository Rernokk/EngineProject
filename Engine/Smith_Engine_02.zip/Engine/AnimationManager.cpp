#include "AnimationManager.h"

void AnimationManager::Start() {
	cout << "Animation Manager Start" << endl;
}

void AnimationManager::Update() {
	cout << "Animation Manager Update" << endl;
}

void AnimationManager::Shutdown() {
	cout << "Animation Manager Shutdown" << endl;
}