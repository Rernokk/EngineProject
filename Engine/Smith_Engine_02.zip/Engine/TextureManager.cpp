#include "TextureManager.h"

void TextureManager::Start() {
	cout << "Texture Manager Start" << endl;
}

void TextureManager::Update() {
	cout << "Texture Manager Update" << endl;
}

void TextureManager::Shutdown() {
	cout << "Texture Manager Shutdown" << endl;
}