#include "PhysicsManager.h"

void PhysicsManager::Start() {
	cout << "Physics Manager Start" << endl;
}

void PhysicsManager::Update() {
	cout << "Physics Manager Update" << endl;
}

void PhysicsManager::Shutdown() {
	cout << "Physics Manager Shutdown" << endl;
}