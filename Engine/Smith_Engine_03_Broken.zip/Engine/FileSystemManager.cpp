#include "FileSystemManager.h"

void FileSystemManager::Start() {
	cout << "File System Manager Start" << endl;
}

void FileSystemManager::Update() {
	cout << "File System Manager Update" << endl;
}

void FileSystemManager::Shutdown() {
	cout << "File System Manager Shutdown" << endl;
}