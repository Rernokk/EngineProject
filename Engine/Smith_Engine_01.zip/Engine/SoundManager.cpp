#include "SoundManager.h"

void SoundManager::Start() {
	cout << "Sound Manager Start" << endl;
}

void SoundManager::Update() {
	cout << "Sound Manager Update" << endl;
}

void SoundManager::Shutdown() {
	cout << "Sound Manager Shutdown" << endl;
}