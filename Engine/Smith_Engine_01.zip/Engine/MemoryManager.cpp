#include "MemoryManager.h"

void MemoryManager::Start() {
	cout << "Memory Manager Start" << endl;
}

void MemoryManager::Update() {
	cout << "Memory Manager Update" << endl;
}

void MemoryManager::Shutdown() {
	cout << "Memory Manager Shutdown" << endl;
}